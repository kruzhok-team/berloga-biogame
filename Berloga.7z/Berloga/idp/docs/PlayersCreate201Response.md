# Org.OpenAPITools.Model.PlayersCreate201Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PlayerId** | **Guid** | Идентификатор игрока. | 
**PlayerSecret** | **string** | Секретный ключ игрока. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

