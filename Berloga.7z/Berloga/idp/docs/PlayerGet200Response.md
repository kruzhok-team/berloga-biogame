# Org.OpenAPITools.Model.PlayerGet200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TalentId** | **int** | Возвращается, если передан параметр &#x60;get_talent_id&#x3D;true&#x60;. Если у игрока не имеется привязанной учетной записи Таланта, значением будет &#x60;null&#x60;. | [optional] 
**PlayerIds** | **List&lt;Guid&gt;** | Возвращается, если передан параметр &#x60;get_player_ids&#x3D;true&#x60;. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

