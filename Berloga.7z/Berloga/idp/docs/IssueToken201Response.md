# Org.OpenAPITools.Model.IssueToken201Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Token** | **string** | Аутентификационный токен. | 
**ExpiresIn** | **int** | Кол-во секунд через которое истечет срок жизни токена. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

