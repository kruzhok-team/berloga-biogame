# Org.OpenAPITools.Model.PlayersCreateRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ApplicationId** | **Guid** | Идентификатор приложения. | 
**DeviceId** | **string** | DeviceID | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

