# Org.OpenAPITools.Model.IssueTokenRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ApplicationId** | **Guid** | Идентификатор приложения. | 
**PlayerId** | **Guid** | Идентификатор игрока. | 
**PlayerSecret** | **string** | Секретный ключ игрока. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

