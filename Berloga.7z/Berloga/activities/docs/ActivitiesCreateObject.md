# Org.OpenAPITools.Model.ActivitiesCreateObject

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Activities** | [**List&lt;ActivitiesCreateListInner&gt;**](ActivitiesCreateListInner.md) |  | 
**Artefacts** | [**List&lt;ActivitiesCreateObjectArtefactsInner&gt;**](ActivitiesCreateObjectArtefactsInner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

