# Org.OpenAPITools.Model.Context
Контекст активностей

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **Guid** | Идентификатор контекста активности. | 
**ApplicationId** | **Guid** |  | 
**TraditionId** | **int** |  | 
**ActivityTypeId** | **int** |  | 
**Description** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

