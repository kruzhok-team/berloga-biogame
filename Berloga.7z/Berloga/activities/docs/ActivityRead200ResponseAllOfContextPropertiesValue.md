# Org.OpenAPITools.Model.ActivityRead200ResponseAllOfContextPropertiesValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ValueString** | **string** |  | 
**ValueNumber** | **decimal** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

