# Org.OpenAPITools.Model.ContextsImport422ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Index** | **int** | Индекс строки в таблице за исключением строки заголовка. | 
**Row** | **Dictionary&lt;string, string&gt;** | Данные импортируемые строкой таблицы. | 
**Errors** | **List&lt;string&gt;** | Ошибки валидации строки. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

