# Org.OpenAPITools.Model.ActivitiesCreateObjectArtefactsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **Guid** | Идентификатор артефакта. | 
**UploadUrl** | **string** | Временный URL для загрузки данных артефакта методом PUT | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

