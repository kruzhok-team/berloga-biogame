# Org.OpenAPITools.Model.ActivityWriteObject

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Activities** | [**List&lt;ActivityWrite&gt;**](ActivityWrite.md) |  | 
**Artefacts** | [**List&lt;ActivityWriteObjectArtefactsInner&gt;**](ActivityWriteObjectArtefactsInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

