# Org.OpenAPITools.Model.TalentUserAwardAllOfDisplayed

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ApplicationId** | **Guid** | Идентификатор приложения. | 
**DisplayedAt** | **DateTime** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

