# Org.OpenAPITools.Model.ChallengesList200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** |  | 
**Description** | **string** |  | 
**IconUrl** | **string** | URL иконки-изображения испытания. | 
**Applications** | **List&lt;Guid&gt;** | Приложения, активности из которых участвуют в испытании. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

