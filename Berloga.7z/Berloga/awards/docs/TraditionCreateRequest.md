# Org.OpenAPITools.Model.TraditionCreateRequest
Создание традиции берлоги

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Название традиции. | 
**Image** | **string** | Изображение традиции. | 
**Description** | **string** | Описание традиции. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

