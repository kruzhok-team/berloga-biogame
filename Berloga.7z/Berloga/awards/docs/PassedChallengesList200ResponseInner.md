# Org.OpenAPITools.Model.PassedChallengesList200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ChallengeId** | **int** |  | 
**PassedAt** | **DateTime** | Дата прохождения испытания | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

